<table class="table">
  <thead>
    <tr>
      <th scope="col">Nama</th>
      <th scope="col">Alamat</th>
      <th scope="col">Jabatan</th>
      <th scope="col">Nama Perusahaan</th>
      <th scope="col">Pilih Surat</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($row->nama); ?></td>
      <td><?php echo e($row->alamat); ?></td>
      <td><?php echo e($row->jabatan); ?></td>
      <td><?php echo e($row->namaPerusahaan); ?></td>
      <td>
        <div class="btn-group">
        <button type="button" class="btn btn-secondary dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            Pilih Surat
        </button>
        <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?php echo e(route('suratijin', $row->id)); ?>">Surat Ijin Kerja</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('suratlamar', $row->id)); ?>">Surat Lamar Kerja</a></li>
        </ul>
        </div>
      <td>
      <button type="button" class="btn btn-warning" onclick="edit('<?php echo e($row->id); ?>')"><i class="fas fa-edit"></i></button>
      <button type="button" class="btn btn-danger" onclick="destroy('<?php echo e($row->id); ?>')"><i class="fas fa-trash"></i></button>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
  </table><?php /**PATH C:\xampp\htdocs\assignment\resources\views/read.blade.php ENDPATH**/ ?>